/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niexiste.vista;


import java.util.ArrayList;
import java.util.Scanner;
import niexiste.controlador.Controlador;

/**
 *
 * @author Victor
 */
public class NiExiste {
    private Controlador control;
    public NiExiste(){
        this.control=new Controlador();
        this.control.addClient("NomClient", "CognomClient", "EmailClient", "AliasClient", "EmpresaClient", "ProjecteClient", "NIEClient", "695326421", "934482371", "12/09/1981");
        this.control.addClient("NomClient2", "CognomClient2", "EmailClient2", "AliasClient2", "EmpresaClient2", "ProjecteClient2", "NIEClient2", "695326422", "934482372", "12/09/1982");
        this.control.addClient("NomClient3", "CognomClient3", "EmailClient3", "AliasClient3", "EmpresaClient3", "ProjecteClient3", "NIEClient3", "695326423", "934482373", "12/09/1983");
        this.control.addClient("NomClient4", "CognomClient4", "EmailClient4", "AliasClient4", "EmpresaClient4", "ProjecteClient4", "NIEClient4", "695326424", "934482374", "12/09/1984");
        this.control.addAmic("NomAmic", "CognomAmic", "EmailAmic", "AliasAmic", "DireccioAmic", "666666", "99999", "12/09/1985");
        this.control.addAmic("NomAmic2", "CognomAmic2", "EmailAmic2", "AliasAmic2", "DireccioAmic2", "6666662", "999992", "12/09/1985");
        this.control.addAmic("NomAmic3", "CognomAmic3", "EmailAmic3", "AliasAmic3", "DireccioAmic3", "6666663", "999993", "12/09/1986");
        this.control.addAmic("NomAmic4", "CognomAmic4", "EmailAmic4", "AliasAmic4", "DireccioAmic4", "6666664", "999994", "12/09/1987");
        this.control.addCita("12/09/1988", "12:33", "LlocCita1", "Y", "1");
        this.control.addCita("12/09/1989", "12:34", "LlocCita2", "N", "2");
        this.control.addCita("12/09/1990", "12:35", "LlocCita3", "Y", "5");
        
        
    }
    public static void main(String[] args){
        NiExiste n = new NiExiste();
        Scanner sc = new Scanner(System.in);
        n.inici(sc);
    }    
    private void inici(Scanner sc){
        String i;
        while(true){
            showMenuInici();
            i = sc.next();
            if(i.equals("1")){
                afegirClient(sc);
                break;
            }else if(i.equals("2")){
                modificarClient(sc);
                break;
            }else if(i.equals("3")){
                veureClients(sc);
                break;
            }else if(i.equals("4")){
                afegirAmic(sc);
                break;
            }else if(i.equals("5")){
                modificarAmic(sc);
                break;
            }else if(i.equals("6")){
                veureAmics(sc);
                break;
            }else if(i.equals("7")){
                afegirCita(sc);
                break;
            }else if(i.equals("8")){
                modificarCita(sc);
                break;
            }else if(i.equals("9")){
                veureCites(sc);
                break;
            }else if(i.equals("666")){
                break;
            }else{
                System.out.println("Aquesta opció no és vàlida. Torna a llegir el menú: ");
            }  
        }   
    }
    
    private void showMenuInici(){
        System.out.println("-----Niexiste-----\n");
        System.out.println("Client");
        System.out.println("1. Afegir Client");
        System.out.println("2. Modificar Client");
        System.out.println("3. Veure tots els Clients");
        System.out.println("Amic");
        System.out.println("4. Afegir Amic");
        System.out.println("5. Modificar Amic");
        System.out.println("6. Veure tots els Amics");
        System.out.println("Cita");
        System.out.println("7. Afegir Cita");
        System.out.println("8. Modificar Cita");
        System.out.println("9. Veure totes les Cites");
        System.out.println("666. Sortir");
    }

    //AMICS
    private void showMenuModificarAmic(){
        System.out.println("Modificar Amic\n");
        System.out.println("1- Nom");
        System.out.println("2- Cognom");
        System.out.println("3- Email");
        System.out.println("4- Alias"); 
        System.out.println("5- Direcció(Acabar en ;)"); 
        System.out.println("6- Telèfon mòbil"); 
        System.out.println("7- Telèfon de casa"); 
        System.out.println("8- Data aniversari(DD/MM/AAAA)"); 
        System.out.println("9- Tornar");
    }
    private void afegirAmic(Scanner sc){
        ArrayList<String> dades = new ArrayList<String>();
        System.out.println("Nom:");
        dades.add(sc.next());
        System.out.println("Cognom:");
        dades.add(sc.next());
        System.out.println("Email:");
        dades.add(sc.next());
        System.out.println("Alias:");
        dades.add(sc.next());
        System.out.println("Direcció de casa(acabant en ;):");
        String dir= "";
        dir = sc.next();
        while(!dir.contains(";")){
            dir+=sc.next();
        }
        dir = dir.substring(0, dir.length()-1);
        dades.add(dir);
        System.out.println("Telèfon mòbil:");
        dades.add(sc.next());
        System.out.println("Telèfon de casa:");
        dades.add(sc.next());
        System.out.println("Data de naixement del client(DD/MM/AAAA):");
        dades.add(sc.next());
        if(this.control.addAmic(dades.get(0), dades.get(1), dades.get(2), dades.get(3), dades.get(4), dades.get(5), dades.get(6), dades.get(7))){
            System.out.println("Afegit correctament!");
        }else{
            System.out.println("Hi ha hagut un error");
        }
        inici(sc);
    }
    private void modificarAmic(Scanner sc){
        System.out.println("ID de l'amic");
        String id = sc.next();
        System.out.println("Buscant id"+ id);
        System.out.println(Integer.parseInt(id));
        if(this.control.containsClient(Integer.parseInt(id))){
            showMenuModificarAmic();
            String prop = sc.next();
            System.out.println("Introdueix el nou valor");
            String valor = sc.next();
            this.control.editAmic(id, prop, valor);
        }
        inici(sc);
    }
    private void veureAmics(Scanner sc){
        System.out.println(this.control.getAmics());
        inici(sc);
    }
    
    //CLIENTS
    private void showMenuModificarClient(){
    System.out.println("Modificar Client\n");
    System.out.println("1- Nom");
    System.out.println("2- Cognom");
    System.out.println("3- Email");
    System.out.println("4- Alias"); 
    System.out.println("5- Empresa"); 
    System.out.println("6- Projecte"); 
    System.out.println("7- NIE"); 
    System.out.println("8- Telèfon privat"); 
    System.out.println("9- Telèfon empresa"); 
    System.out.println("10- Data aniversari(DD/MM/AAAA)"); 
    System.out.println("11- Tornar");
}
    private void afegirClient(Scanner sc){
    ArrayList<String> dades = new ArrayList<String>();
    System.out.println("Nom del client:");
    dades.add(sc.next());
    System.out.println("Cognom del client:");
    dades.add(sc.next());
    System.out.println("Email del client:");
    dades.add(sc.next());
    System.out.println("Alias del client:");
    dades.add(sc.next());
    System.out.println("Empresa del client:");
    dades.add(sc.next());
    System.out.println("Projecte del client:");
    dades.add(sc.next());
    System.out.println("NIE del client:");
    dades.add(sc.next());
    System.out.println("Telèfon personal del client:");
    dades.add(sc.next());
    System.out.println("Telèfon de la feina del client:");
    dades.add(sc.next());
    System.out.println("Data de naixement del client(DD/MM/AAAA):");
    dades.add(sc.next());

    if(this.control.addClient(dades.get(0), dades.get(1), dades.get(2), dades.get(3), dades.get(4), dades.get(5), dades.get(6), dades.get(7), dades.get(8), dades.get(9))){
        System.out.println("Afegit correctament!");
    }else{
        System.out.println("Hi ha hagut un error");
    }
    inici(sc);
}
    private void modificarClient(Scanner sc){
    System.out.println("ID del client");
    String id = sc.next();
    System.out.println("Buscant id"+ id);
    System.out.println(Integer.parseInt(id));
    if(this.control.containsClient(Integer.parseInt(id))){
        showMenuModificarClient();
        String prop = sc.next();
        System.out.println("Introdueix el nou valor");
        String valor = sc.next();
        this.control.editClient(id, prop, valor);
    }
    inici(sc);
}
    private void veureClients(Scanner sc){
    System.out.println(this.control.getClients());
    inici(sc);
}
    
    //CITES
    private void showMenuModificarCita(){
        System.out.println("Modificar Cita\n");
        System.out.println("1- Data(DD/MM/AAAA)");
        System.out.println("2- Hora(HH:MM)");
        System.out.println("3- Lloc(Acabar en ;)");
        System.out.println("4- Confirmació(Y-N)"); 
        System.out.println("5- ID de la persona citada"); 
        
    }
    private void afegirCita(Scanner sc){
        ArrayList<String> dades = new ArrayList<String>();
        System.out.println("Data(DD/MM/AAAA):");
        dades.add(sc.next());
        System.out.println("Hora(HH:MM):");
        dades.add(sc.next());
        System.out.println("Lloc(Acabar en ;):");
        String dir= "";
        dir = sc.next();
        while(!dir.contains(";")){
            dir+=sc.next();
        }
        dir = dir.substring(0, dir.length()-1);
        dades.add(dir);
        System.out.println("Confirmació(Y-N):");
        dades.add(sc.next());
        System.out.println("ID de la persona citada:");
        dades.add(sc.next());
        if(this.control.addCita(dades.get(0), dades.get(1), dades.get(2), dades.get(3), dades.get(4))){
            System.out.println("Afegit correctament!");
        }else{
            System.out.println("Hi ha hagut un error");
        }
        inici(sc);
        
    }
    private void modificarCita(Scanner sc){
        System.out.println("ID de la cita");
        String id = sc.next();
        System.out.println("Buscant id"+ id);
        System.out.println(Integer.parseInt(id));
        if(this.control.containsCita(Integer.parseInt(id))){
            showMenuModificarCita();
            String prop = sc.next();
            System.out.println("Introdueix el nou valor");
            String valor = sc.next();
            this.control.editCita(id, prop, valor);
        }
        inici(sc);
    }
    private void veureCites(Scanner sc){
        System.out.println(this.control.getCites());
        inici(sc);
    }
}

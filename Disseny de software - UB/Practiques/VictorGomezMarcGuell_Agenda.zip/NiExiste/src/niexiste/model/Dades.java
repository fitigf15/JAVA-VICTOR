/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package niexiste.model;

import java.util.ArrayList;

/**
 *
 * @author vgomezfa10.alumnes
 */
public class Dades {
    
    private ArrayList<Amic> amics;
    private ArrayList<Client> clients;
    private ArrayList<Cita> cites;
    private ArrayList<Lloc> llocs;
    private Empleat currentEmpleat;
    
    public Dades(Empleat e){
        this.amics = new ArrayList();
        this.clients = new ArrayList();
        this.cites = new ArrayList();
        this.llocs = new ArrayList();
        this.currentEmpleat=e;
        
    }

    public void addAmic(Amic amic) {
        this.amics.add(amic);
    }

    public void addClient(Client client) {
        this.clients.add(client);
    }
    
    public void setCurrentEmpleat(Empleat e){
        this.currentEmpleat=e;
    }

    public void addCita(Cita cita) {
        this.cites.add(cita);
    }
    public void addLloc(Lloc lloc){
        this.llocs.add(lloc);
    }
    public ArrayList<Amic> getAmics(){
        return this.amics;
    }
    public ArrayList<Client> getClients(){
        return this.clients;
    }
    public ArrayList<Cita> getCites(){
        return this.cites;
    }
    public ArrayList<Lloc> getLlocs(){
        return this.llocs;
    }
    public Empleat getCurrentEmpleat(){
        return this.currentEmpleat;
    }
    
    
    
}

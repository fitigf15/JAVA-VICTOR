/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niexiste.model;

import java.util.Date;

/**
 *
 * @author mguellji7.alumnes
 */
public class Empleat extends Persona{
    private String seccio;
    private int sou;
    private Date dataInici;
    private String username;
    private String password;
    
    public Empleat(String name, String surname, String mail, String al, int i,int phone,Date aniv) {
        super(name, surname, mail,al,i, phone,aniv);
    }
    
    public Empleat(String name, String surname, String mail, String al, int i,int phone,Date aniv ,String seccion, int sueldo, Date anoInicio, String user, String pass){
        super(name, surname, mail,al,i, phone,aniv);
        this.seccio = seccion;
        this.sou = sueldo;
        this.dataInici = anoInicio;
        this.username=user;
        this.password=pass;
    }
    
    public void setSeccio(String sec){
        this.seccio = sec;
    }
    public void setSou(int so){
        this.sou = so;
    }
    public void setDataInici(Date inici){
        this.dataInici = inici;        
    }
    public String getSeccio(){
        return this.seccio;
    }
    public int getSou(){
        return this.sou;
    }
    public Date getDateInici(){
        return this.dataInici;
    }
    public String getUsername(){
        return this.username;
    }
    
}
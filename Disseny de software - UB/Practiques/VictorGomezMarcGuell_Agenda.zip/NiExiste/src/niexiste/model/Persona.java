/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package niexiste.model;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author vgomezfa10.alumnes
 */
public abstract class Persona {
    private String nom;
    private String cognoms;
    private String correu;
    private String alias;
    private final int id;
    private int telefon;
    private Date dataNaixement;
    private ArrayList<Lloc> llocsPreferits;
    
    public Persona(String name, String surname, String mail, String al, int i, int phone, Date aniv){
        this.nom = name;
        this.cognoms = surname;
        this.correu = mail;
        this.alias = al;
        this.id = i;
        this.telefon= phone;
        this.dataNaixement=aniv;
        this.llocsPreferits=new ArrayList();
    }
    public Persona(String name, String surname, String mail, String al, int phone, Date aniv){
        this.nom = name;
        this.cognoms = surname;
        this.correu = mail;
        this.alias = al;
        this.id = -1;
        this.telefon= phone;
        this.dataNaixement=aniv;
        this.llocsPreferits=new ArrayList();
    }
    public void addLlocPreferit(Lloc l){
        this.llocsPreferits.add(l);
    }
    public ArrayList<Lloc> getLlocsPreferits(){
        return this.llocsPreferits;
    }
    public void setCognoms(String str){
        this.cognoms= str;
    }
    public void setCorreu(String str){
        this.correu = str;
    }
    public void setNom(String str){
        this.nom = str;
    }
    public void setAlias(String str){
        this.alias = str;
    }
    public void setDataNaixement(Date aniv){
        this.dataNaixement =aniv;
    }
    public void setTelefon(int i){
        this.telefon = i;
    }
    public String getNom(){
        return this.nom;
    }
    public String getCognoms(){
        return this.cognoms;
    }
    public String getCorreu(){
        return this.correu;
    }
    public String getAlias(){
        return this.alias;
    }
    public int getId(){
        return this.id;
    }
    public int getTelefon(){
        return this.telefon;
    }
    public Date getDataNaixement(){
        return this.dataNaixement;
    }
    public boolean equals(Persona p){
        if(p.getId()==-1) return this.nom.equals(p.getNom())&&this.cognoms.equals(p.getCognoms())&&this.alias.equals(p.getAlias());
        return this.id==p.getId();
        
    }
    public boolean equals(int i){
        return i==this.id;
    }

}

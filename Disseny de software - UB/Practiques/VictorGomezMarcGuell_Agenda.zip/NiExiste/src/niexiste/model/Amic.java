/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package niexiste.model;

import java.util.Date;

/**
 *
 * @author vgomezfa10.alumnes
 */
public class Amic extends Persona{

    private String direccio;
    private int telfCasa;
    
    public Amic(String name, String surname, String mail, String al,int id, String direction, int phone, int homePhone, Date aniv) {
        super(name, surname, mail, al,id, phone,aniv);
        this.direccio=direction;
        this.telfCasa=homePhone;
        
    }
    public Amic(String name, String surname, String mail, String al, String direction, int phone, int homePhone, Date aniv) {
        super(name, surname, mail, al, phone,aniv);
        this.direccio=direction;
        this.telfCasa=homePhone;
    }
    
    public void setDireccio(String str){
        this.direccio = str;
    }
    public void setTelfCasa(int i){
        this.telfCasa = i;
    }
    public String getDireccio(){
        return this.direccio;
    }
    public int getTelfCasa(){
        return this.telfCasa;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niexiste.model;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Victor
 */
public class IdArrayList implements Iterable<Object> {
    private final ArrayList llista;
    private final String tipus;
    public IdArrayList(String tipus){
        this.llista = new ArrayList();
        this.tipus=tipus;
    }
    public void add(Object o){
        if("AMIC".equals(this.tipus)){
            this.llista.add((Amic)o);
        }else if("CLIENT".equals(this.tipus)){
            this.llista.add((Client)o);
        }else if("LLOC".equals(this.tipus)){
            this.llista.add((Lloc)o);
        }else if("CITA".equals(this.tipus)){
            this.llista.add((Cita)o);
        }
    }
    public Object get(Object o){
        if("AMIC".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Amic p = (Amic)it.next();
                if(p.equals((Amic)o)){
                    return p;
                }
            }
            return null;
        }
        if("CLIENT".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Client p = (Client)it.next();
                if(p.equals((Amic)o)){
                    return p;
                }
            }
            return null;
        }
        if("LLOC".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Lloc l = (Lloc)it.next();
                if(l.equals((Lloc)o)){
                    return l;
                }
            }return null;
            
        }
        if("CITA".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Cita c = (Cita)it.next();
                if(c.equals((Cita)o)){
                    return c;
                }
            }return null;
            
        }
        return null;
        
    }
    public boolean contains(Object o){
        if("AMIC".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Amic p = (Amic)it.next();
                if(p.equals((Amic)o)){
                    return true;
                }
            }
            return false;
        }
        if("CLIENT".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Client p = (Client)it.next();
                if(p.equals((Client)o)){
                    return true;
                }
            }
            return false;
        }
        if("LLOC".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Lloc l = (Lloc)it.next();
                if(l.equals((Lloc)o)){
                    return true;
                }
            }return false;
            
        }
        if("CITA".equals(this.tipus)){
            for (Iterator it = this.llista.iterator(); it.hasNext();) {
                Cita c = (Cita)it.next();
                if(c.equals((Cita)o)){
                    return true;
                }
            }return false;
            
        }
        return false;
        
    }
    @Override
    public Iterator<Object> iterator() {
        return this.llista.iterator();
    }
}

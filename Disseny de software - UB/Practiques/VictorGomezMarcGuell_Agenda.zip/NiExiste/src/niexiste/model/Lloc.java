/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niexiste.model;

/**
 *
 * @author Victor
 */
public class Lloc {
    private String nom;
    private final int id;
    //private double latitud;
    //private double longitud;
    public Lloc(String n, int i){//double lat, double lon
        this.nom=n;
        //this.latitud=lat;
        //this.longitud=lon;
        this.id=i;
    }
    public Lloc(String n){
        this.nom=n;
        this.id = -1;
    }
    public String getNom(){
        return this.nom;
    }
    /*
    public double getLatitud(){
        return this.latitud;
    }
    public double getLongitud(){
        return this.longitud;
    }
    public void setLatitud(double lat){
        this.latitud = lat;
    }
    public void setLongitud(double lon){
        this.longitud= lon;
    }
    */
    public int getId(){
        return this.id;
    }
    public void setNom(String str){
        this.nom = str;
    }
    public boolean equals(Lloc l){
        return this.id==l.getId();
    }
    public boolean equals(int i){
        return this.id==i;
    }
    
    
}

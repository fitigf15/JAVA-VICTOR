/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package niexiste.model;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author vgomezfa10.alumnes
 */
public class Cita {
    private Date data; 
    private Lloc lloc;
    private boolean acceptat;
    private Persona ambQui;
    private final int id;
    
    public Cita(Date d, Lloc l, boolean ok, Persona qui, int i){
        this.data = d;
        this.lloc = l;
        this.acceptat = ok;
        this.ambQui = qui;
        this.id=i;
    }
    public Cita(Date d, Lloc l, boolean ok, Persona qui){
        this.data = d;
        this.lloc = l;
        this.acceptat = ok;
        this.ambQui = qui;
        this.id=-1;
    }
    public Date getData(){
        return this.data;
    }
    public Lloc getLloc(){
        return this.lloc;
    }
    public boolean getAcceptat(){
        return this.acceptat;
    }
    public Persona getambQui(){
        return this.ambQui;
    }
    public int getId(){
        return this.id;
    }
    public void setData(Date date){
        this.data = date;
    }
    public void setHora(int i){
        this.data.setHours(i);
    }
    public void setMinuts(int i){
        this.data.setMinutes(i);
    }
    public void setDia(int i){
        this.data.setDate(i);
    }
    public void setMes(int i){
        this.data.setMonth(i);
    }
    public void setAny(int i){
        this.data.setYear(i);
    }
    public void setLloc(Lloc l){
        this.lloc = l;
    }
    public void setAcceptat(boolean acceptat){
        this.acceptat = acceptat;
    }
    public void setambQui(Persona ambQui){
        this.ambQui = ambQui;
    }
    public boolean equals(Cita c){
        if(c.getId()==-1) return this.data.equals(c.getData())&&this.lloc.equals(c.getLloc())&&this.acceptat==c.getAcceptat()&&this.ambQui.equals(c.getambQui());
        return this.id==c.getId();
    }
    public boolean equals(int i){
        return this.id==i;
    }
    
}

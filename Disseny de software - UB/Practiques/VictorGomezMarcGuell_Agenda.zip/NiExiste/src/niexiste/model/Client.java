/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package niexiste.model;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author vgomezfa10.alumnes
 */
public class Client extends Persona {

    private String empresa;
    private String projecte;
    private String nieEmpresa;
    private int telfEmpresa;
    
    
    public Client(String name, String surname, String mail, String al, int id, int phone, Date aniv) {
        super(name, surname, mail, al,id, phone, aniv);
    }public Client(String name, String surname, String mail, String al, int phone, Date aniv) {
        super(name, surname, mail, al, phone, aniv);
    }
    
    /*
    */
    public Client(String name, String surname, String mail, String al,int id, String nie, String enterprise, String project, int phone, int workPhone, Date aniv){
        super(name, surname, mail,al,id, phone,aniv);
        this.empresa=enterprise;
        this.projecte = project;
        this.nieEmpresa = nie;
        this.telfEmpresa = workPhone;
        
    }
    public Client(String name, String surname, String mail, String al, String nie, String enterprise, String project, int phone, int workPhone, Date aniv){
        super(name, surname, mail,al,phone,aniv);
        this.empresa=enterprise;
        this.projecte = project;
        this.nieEmpresa = nie;
        this.telfEmpresa = workPhone;
    }
    public void setEmpresa(String str){
        this.empresa = str;
    }
    public void setNieEmpresa(String str){
        this.nieEmpresa= str;
    }
    public void setProjecte(String str){
        this.projecte = str;
    }
    public void setTelfEmpresa(int i){
        this.telfEmpresa = i;
    }
    
    public String getEmpresa(){
        return this.empresa;
    }
    public String getProjecte(){
        return this.projecte;
    }
    public String getNieEmpresa(){
        return this.nieEmpresa;
    }
    public int getTelfEmpresa(){
        return this.telfEmpresa;
    }
    
    
    
    
}

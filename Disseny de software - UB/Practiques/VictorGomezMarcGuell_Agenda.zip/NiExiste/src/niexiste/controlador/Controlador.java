/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package niexiste.controlador;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import javax.swing.DefaultComboBoxModel;
import niexiste.model.Amic;
import niexiste.model.Cita;
import niexiste.model.Client;
import niexiste.model.Dades;
import niexiste.model.Empleat;
import niexiste.model.IdArrayList;
import niexiste.model.Lloc;
import niexiste.model.Persona;

/**
 *
 * @author Victor
 */
public class Controlador {
    private final Dades dades;
    private int newIdPersona;
    private int newIdCita;
    private int newIdLloc;
    public Controlador(){
        this.newIdPersona=0;
        this.newIdCita=0;
        this.newIdLloc=0;
        this.dades=new Dades(null);
    }
    public void setCurrentEmpleat(String name, String surname, String mail, String al,int phone,Date aniv ,String seccion, int sueldo, Date anoInicio, String user, String pass){
        this.newIdPersona++;
        this.dades.setCurrentEmpleat(new Empleat(name, surname, mail, al, this.newIdPersona,phone,aniv ,seccion, sueldo, anoInicio, user, pass));
    }
    
    

    
    // METODES AMIC
    public String getAmics(){
        String s = "";
        for (Amic p : this.dades.getAmics()) {
            s +="ID: "+p.getId()+". NOM: "+p.getNom()+", COGNOM:"+p.getCognoms()+", ALIAS: "+p.getAlias()+", CORREU: "+p.getCorreu()+", TELEFON PERSONAL: "+p.getTelefon()+", TELEFON DE CASA: "+p.getTelfCasa()+",\n DATA DE NAIXEMENT: "+p.getDataNaixement()+", DIRECCIÓ: "+p.getDireccio()+"\n";
            s +="LLOCS PREFERITS: \n";
            for(Lloc l: p.getLlocsPreferits()){
                s+=l.getId()+", ";
            }
            s+="\n";
        }
        return s;
    }
    public boolean addAmic(String name, String surname, String mail, String al, String direction, String phone, String homePhone, String aniv){
        this.newIdPersona++;
        this.dades.addAmic(new Amic(name,surname,mail,al,this.newIdPersona,direction,Integer.valueOf(phone),Integer.valueOf(homePhone),this.parseDate(aniv)));
        return true;
    }
    public boolean editAmic(String id,String prop,String val){
        for(Amic p : this.dades.getAmics()){
            if(p.getId()==Integer.parseInt(id)){
                
                switch(Integer.parseInt(prop)){
                    case 1:
                        p.setNom(val);return true;
                    case 2:
                        p.setCognoms(val);return true;
                    case 3:
                        p.setCorreu(val);return true;
                    case 4:
                        p.setAlias(val);return true;
                    case 5:
                        p.setDireccio(val);return true;
                    case 6:
                        p.setTelefon(Integer.parseInt(val));
                        return true;
                    case 7:
                        p.setTelfCasa(Integer.parseInt(val));
                        return true;
                    case 8:
                        p.setDataNaixement(this.parseDate(val));
                        return true;
                    case 9:
                        return false;
                    default:
                        return false;
                    
                }
            }
        }
        return false;
    }
    public boolean containsAmic(Amic a){
        for (Iterator it = this.dades.getAmics().iterator(); it.hasNext();) {
            Amic p = (Amic)it.next();
            if(p.equals(a))return true;
        }
        return false;
    }
    public boolean containsAmic(int a){
        for (Amic p : this.dades.getAmics()){
            System.out.println(p.equals(a));
            if(p.equals(a))return true;
        }
        return false;
    }
    
    public Amic getAmicByClass(Amic a){
        for (Amic p : this.dades.getAmics()) {
            if(p.equals(a))return p;
        }
        return null;
    }
    public Amic getAmicById(int id){
        for (Amic p : this.dades.getAmics()) {
            if(p.getId()==id){
                return p;
            }
        }
        return null;
    }
    public Amic getAmicByTelf(int telf){
        for (Amic p : this.dades.getAmics()) {
            if(p.getTelefon()==telf)return p;
            if(p.getTelfCasa()==telf) return p;
        }
        return null;
    }
    public Amic getAmicByCognoms(String str){
        for (Amic p : this.dades.getAmics()) {
            if(p.getCognoms().equals(str)) return p;
        }
        return null;  
    }
    public Amic getAmicByAlias(String str){
        for (Amic p : this.dades.getAmics()) {
            if(p.getAlias().equals(str)) return p;
        }
        return null;  
    }
    public Amic getAmicByCorreu(String str){
        for (Amic p : this.dades.getAmics()) {
            if(p.getCorreu().equals(str)) return p;
        }
        return null;  
    }
    public Amic getAmicByDireccio(String str){
        for (Amic p : this.dades.getAmics()) {
            if(p.getDireccio().equals(str)) return p;
        }
        return null;  
    }
    
    //METODES CLIENT
    public String getClients(){
        String s = "";
        for (Client p : this.dades.getClients()) {
            s +="ID: "+p.getId()+". NOM: "+p.getNom()+", COGNOM:"+p.getCognoms()+", ALIAS: "+p.getAlias()+", CORREU: "+p.getCorreu()+", TELEFON PERSONAL: "+p.getTelefon()+",\n TELEFON EMPRESA: "+p.getTelfEmpresa()+", PROJECTE: "+p.getProjecte()+", EMPRESA: "+p.getEmpresa()+", NIE: "+p.getNieEmpresa()+", DATA DE NAIXEMENT: "+p.getDataNaixement()+"\n";
            s +="LLOCS PREFERITS: \n";
            for(Lloc l: p.getLlocsPreferits()){
                s+=l.getId()+", ";
            }
            s+="\n";
        }
        return s;
    }
    public boolean addClient(String name, String surname, String mail, String al, String enterprise, String project, String nie, String phone, String workPhone, String aniv){
        this.newIdPersona++;
        this.dades.addClient(new Client(name, surname, mail, al,this.newIdPersona, enterprise, project, nie, Integer.valueOf(phone), Integer.parseInt(workPhone),this.parseDate(aniv)));
        return true;
    }
    public boolean editClient(String id,String prop,String val){
        for(Client p : this.dades.getClients()){
            if(p.getId()==Integer.parseInt(id)){
                
                switch(Integer.parseInt(prop)){
                    case 1:
                        p.setNom(val);return true;
                    case 2:
                        p.setCognoms(val);return true;
                    case 3:
                        p.setCorreu(val);return true;
                    case 4:
                        p.setAlias(val);return true;
                    case 5:
                        p.setEmpresa(val);return true;
                    case 6:
                        p.setProjecte(val);return true;
                    case 7:
                        p.setNieEmpresa(val);return true;
                        
                    case 8:
                        p.setTelefon(Integer.parseInt(val));
                        return true;
                    case 9:
                        p.setTelfEmpresa(Integer.parseInt(val));
                        return true;
                        
                    case 10:
                        p.setDataNaixement(this.parseDate(val));
                        return true;
                    case 11:
                        return false;
                    default:
                        return false;
                    
                }
            }
        }
        return false;
    }
    public boolean containsClient(Client a){
        for (Client p : this.dades.getClients()) {
            if(p.equals(a))return true;
        }
        return false;
    }
    public boolean containsClient(int a){
        for (Client p : this.dades.getClients()){
            System.out.println(p.equals(a));
            if(p.equals(a))return true;
        }
        return false;
    }
    public Client getClientByClass(Client a){
        for (Client p : this.dades.getClients()){
            if(p.equals(a))return p;
        }
        return null;
    }
    public Client getClientByTelf(int telf){
        for(Client p : this.dades.getClients()){
            if(p.getTelefon()==telf)return p;
            if(p.getTelfEmpresa()==telf) return p;
        }
        return null;
    }
    public Client getClientByCognoms(String str){
        for(Client p : this.dades.getClients()){
            if(p.getCognoms().equals(str)) return p;
        }
        return null;  
    }
    public Client getClientByCorreu(String str){
        for(Client p : this.dades.getClients()){
            if(p.getCorreu().equals(str)) return p;
        }
        return null;  
    }
    public Client getClientByNieEmpresa(String str){
        for(Client p : this.dades.getClients()){
            if(p.getNieEmpresa().equals(str)) return p;
        }
        return null;  
    }
    public Client getClientById(int id){
        for(Client p : this.dades.getClients()){
            if(p.getId()==id){
                return p;
            }
        }
        return null;
    }
    public DefaultComboBoxModel getModelClients(){
        DefaultComboBoxModel model = new DefaultComboBoxModel();
        for (Client p : this.dades.getClients()){
            model.addElement(p);
        }
        return model;
    }
    //METODES LLOC
    public boolean containsLloc(Lloc a){
        for (Lloc p : this.dades.getLlocs()) {
            if(p.equals(a))return true;
        }
        return false;
    }
    public Lloc getLlocByClass(Lloc a){
        for (Lloc p : this.dades.getLlocs()) {
            if(p.equals(a))return p;
        }
        return null;
    }
    public Lloc getLlocById(int id){
        for (Lloc p : this.dades.getLlocs()) {
            if(p.getId()==id){
                return p;
            }
        }
        return null;
    }
    //METODES CITA
    public String getCites(){
        String s = "";
        for (Cita p : this.dades.getCites()) {
            s+="ID: "+p.getId()+", DATA: "+p.getData()+", LLOC: "+p.getLloc().getNom()+", CONFIRMACIÓ: "+p.getAcceptat()+"\n, AMB LA PERSONA: "+p.getId()+" "+p.getambQui().getNom()+" "+p.getambQui().getCognoms()+" "+p.getambQui().getAlias()+"\n";
        }
        return s;
    }
    public boolean addCita(String dia, String hora, String nomLloc, String ok, String qui){
        Date d = this.parseDate(dia,hora);
        Lloc l = new Lloc(nomLloc);        
        if(!this.containsLloc(l)){
            this.newIdLloc++;
            l = new Lloc(nomLloc,this.newIdLloc);
            this.dades.addLloc(l);
        }else{
            l = this.getLlocByClass(l);
        }
        Persona p = this.getPersonaById(Integer.parseInt(qui));
        
        

        Cita c = new Cita(d,l, "Y".equals(ok),p);

        if(!this.dades.getCites().contains(c)){
            this.newIdCita++;
            p.addLlocPreferit(l);
            this.dades.addCita(new Cita(d, l, "Y".equals(ok), p,this.newIdCita));
            return true;
        }
        return false;
        
    }
    public boolean containsCita(Cita a){
        for (Cita p:dades.getCites()){
            if(p.equals(a))return true;
        }
        return false;
    }
    public boolean containsCita(int a){
        for (Cita p:dades.getCites()){
            if(p.equals(a))return true;
        }
        return false;
    }
    public boolean editCita(String id,String prop,String val){
        for(Cita p : this.dades.getCites()){
            if(p.getId()==Integer.parseInt(id)){
                
                switch(Integer.parseInt(prop)){
                    case 1:
                        p.setDia(Integer.parseInt(val.substring(0, val.indexOf("/"))));
                        p.setMes(Integer.parseInt(val.substring(val.indexOf("/")+1, val.lastIndexOf("/"))));
                        p.setAny(Integer.parseInt(val.substring(val.lastIndexOf("/")+1, val.length()))-1900);
                        return true;
                    case 2:

                        p.setHora(Integer.parseInt(val.substring(0, val.indexOf(":"))));
                        p.setMinuts(Integer.parseInt(val.substring(val.indexOf(":")+1,val.length())));
                        return true;
                    case 3:
                        p.setLloc(new Lloc(val));return true;
                    case 4:
                        p.setAcceptat(val=="Y");return true;
                    case 5:
                        p.setambQui(this.getPersonaById(Integer.parseInt(val)));return true;
                    case 6:
                        return false;
                    default:
                        return false;
                    
                }
            }
        }
        return false;
    }
    public Cita getCitaByClass(Cita a){
        for (Cita p:dades.getCites()){
            if(p.equals(a))return p;
        }
        return null;
    }
    public Cita getCitaById(int id){
        for (Cita p:dades.getCites()){
            if(p.getId()==id){
                return p;
            }
        }
        return null;
    }
    public DefaultComboBoxModel getModelCites(){
        DefaultComboBoxModel model = new DefaultComboBoxModel();
        for (Iterator it = this.dades.getAmics().iterator(); it.hasNext();) {
            Amic p = (Amic)it.next();
            model.addElement(p);
        }
        return model;
    }
    
    public Persona getPersonaById(int id){
        for(Client p : this.dades.getClients()){
            if(p.getId()==id){
                return p;
            }
        }
        for(Amic p : this.dades.getAmics()){
            if(p.getId()==id){
                return p;
            }
        }
        return null;
    }
    private Date parseDate(String s){
        return new Date(Integer.parseInt(s.substring(s.lastIndexOf("/")+1, s.length()))-1900,
                Integer.parseInt(s.substring(s.indexOf("/")+1, s.lastIndexOf("/"))),
                Integer.parseInt(s.substring(0, s.indexOf("/")))
        );
        
    }
    private Date parseDate(String date,String hour){
        Date d = new Date();
        d.setDate(Integer.parseInt(date.substring(0, date.indexOf("/"))));
        d.setMonth(Integer.parseInt(date.substring(date.indexOf("/")+1, date.lastIndexOf("/"))));
        d.setYear(Integer.parseInt(date.substring(date.lastIndexOf("/")+1, date.length()))-1900);
        d.setHours(Integer.parseInt(hour.substring(0, hour.indexOf(":"))));
        d.setMinutes(Integer.parseInt(hour.substring(hour.indexOf(":")+1,hour.length())));
        return d;
    }
    
    public DefaultComboBoxModel getModelAmics(){
        DefaultComboBoxModel model = new DefaultComboBoxModel();
        for (Iterator it = this.dades.getAmics().iterator(); it.hasNext();) {
            Amic p = (Amic)it.next();
            model.addElement(p.getNom()+" "+p.getCognoms()+" ("+p.getId()+")");
        }
        return model;
    }

    public ArrayList<String> getClientFromModel(String item) {
        int id = Integer.parseInt(item.substring(item.indexOf("(")+1,item.indexOf(")")-1));
        Client c = this.getClientById(id);
        Date d = c.getDataNaixement();
        ArrayList<String> data = new ArrayList<String>();
        data.add(c.getNom());
        data.add(c.getCognoms());
        data.add(c.getAlias());
        data.add(c.getCorreu());
        data.add(d.getDate()+"/"+d.getMonth()+"/"+d.getYear());
        data.add(String.valueOf(c.getTelefon()));
        data.add(String.valueOf(c.getTelfEmpresa()));
        data.add(c.getEmpresa());
        data.add(c.getProjecte());
        data.add(c.getNieEmpresa());
        return data;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine;

/**
 *
 * @author Victor
 */
public class Butaca {
    private int fila;
    private int columna;
    private int id;
    private boolean lliure;
    
    public Butaca(int f,int c,int i,boolean l){
        this.fila=f;
        this.columna=c;
        this.id=i;
        this.lliure=l;
    }
    
}

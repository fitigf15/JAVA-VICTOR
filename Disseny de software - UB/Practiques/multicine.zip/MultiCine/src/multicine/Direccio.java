/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine;

/**
 *
 * @author Victor
 */
public class Direccio {
    private String carrer;
    private String poblacio;
    private int codi_postal;
    
    public Direccio(String c,String p, int cp){
        this.carrer=c;
        this.poblacio=p;
        this.codi_postal=cp;
    }
}



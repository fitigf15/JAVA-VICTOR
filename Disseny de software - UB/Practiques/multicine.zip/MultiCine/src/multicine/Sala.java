/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine;

import java.util.ArrayList;

/**
 *
 * @author Victor
 */
public class Sala {
    private ArrayList<Butaca> butaques;
    private int id;
    
    public Sala(ArrayList<Butaca> b, int i){
        this.butaques=b;
        this.id=i;
    }
    
}

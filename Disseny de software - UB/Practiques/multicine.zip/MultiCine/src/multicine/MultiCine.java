/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Victor
 */
public class MultiCine {
    private Cartellera cartellera;
    private ArrayList<Cinema> cinemes;
    private ArrayList<Compra> compres;
    private ArrayList<Usuari> usuaris;
    
    private Session currentSessio;
    
    public void veurePelicules(){
        boolean stop=false;
        while(!stop){
            mostrarPelicles();
            int index = preguntarIndex();
            int[3] dadesCompra = preguntarCompra(index);
            if(dadesCompra){
                executarcompra(dadesCompra[0]...);
            }
            
        }
        
        
    }
    
    public void mirarCompra(){
        for(cli in clients){
            totalGastat = 0;
            for compra in client.getCompres(){
                print compra.getData
                for entrada in client.getEntrades{
                    
                }
            }
        }
    }
    
    public int[3] preguntarCompra(idPeli){
        int idCine = preguntarCine();
        int idSessio = preguntarSessio();
        return [idPeli,idCine,idSessio];
               
    }
    
    public void executarCompra(int idPelicula, idSessio, int idButaca){
        Compra c = new Compra();
        Entrada e = new Entrada(idPelicula,idSessio,idButaca);
        c.addEntrada(e);
        
    }
    
    public void generarInformePelicules(){
        HashMap<int,int> countPelicules = new HashMap<int,int>();
        for compra in compres{
            for entrada in compres{
                if(countPelicules.get(id)){
                    countPelicules[id]++;
                }else{
                    countPelicules[id]=1;
                }
            }
        }
        
        for (int i=0,i<10,i++){
            id = countPelicules.getMax();
            mostrarPelicula(id);
        }
    }
    
}

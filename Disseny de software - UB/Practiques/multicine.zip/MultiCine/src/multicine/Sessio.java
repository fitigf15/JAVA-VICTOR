/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine;

import java.util.Date;

/**
 *
 * @author Victor
 */
public class Sessio {
    private Pelicula pelicula;
    private Sala sala;
    private Date data_hora;
    
    public Sessio(Pelicula p,Sala s,Date d){
        this.pelicula=p;
        this.sala=s;
        this.data_hora=d;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine;
import java.util.ArrayList;
import java.util.Date;
/**
 *
 * @author Victor
 */
public class Compra {
    private ArrayList<Entrada> entrades;
    private Date data_compra;
    
    public Compra(ArrayList<Entrada> e, Date dc){
        this.entrades=e;
        this.data_compra=dc;
    }
}

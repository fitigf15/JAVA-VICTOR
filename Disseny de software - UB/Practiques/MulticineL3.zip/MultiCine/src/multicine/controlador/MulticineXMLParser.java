package multicine.controlador;

import multicine.controlador.MulticineDataManager;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import multicine.model.*;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 * Parser per a obtenir dades d'un fitxer XML d'Multicine
 * 
 * @author  Professors disseny
 *
 */
public class MulticineXMLParser {

	/**
	 * Data manager
	 */
	MulticineDataManager m_dataManager;
        private MultiCine m_multiCine;

	/**
	 * Constructor
	 */
	public MulticineXMLParser(MulticineDataManager dataManager) {
		this.m_dataManager = dataManager;
	}
	
	/**
	 * Parseja un fitxer XML d'Multicine i guarda les dades al sistema 
	 * 
	 * @param nomFitxer
	 */
	public void parse(String nomFitxer) {
		try {
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse (new File(nomFitxer));
			doc.getDocumentElement().normalize();

			// Obtenim dades
			this.obtenirPelicules(doc);
			this.obtenirCinemes(doc);
			this.obtenirAdministradors(doc);
			this.obtenirClients(doc);
		}
		catch (SAXParseException err) {
			System.out.println ("** Error parsejant" +", linia " + err.getLineNumber () + ", uri " + err.getSystemId ());
			System.out.println(" " + err.getMessage ());
		}
		catch (SAXException e) {
			Exception x = e.getException ();
			((x == null) ? e : x).printStackTrace (); 
		}
		catch (Throwable t) {
			t.printStackTrace ();
		}
	}

	/**
	 * Obte les pelicules de la cadena Multicine
	 * 
	 * @param doc document XML del que obtenir les dades
	 */
	private void obtenirPelicules(Document doc) {
		NodeList pelicules = doc.getElementsByTagName("pelicula");
		String id, titol, any, director, argument, imatge;
		int numPelicules = pelicules.getLength();

		// Parsejo tots els elements pelicula
		for(int i=0; i<numPelicules; i++) {
			Node pelicula = pelicules.item(i);

			if(pelicula.getNodeType() == Node.ELEMENT_NODE){
				Element ePelicula = (Element)pelicula;
				id = pelicula.getAttributes().getNamedItem("id").getTextContent();

				NodeList nTitol = ePelicula.getElementsByTagName("titol");
				Element eTitol = (Element)nTitol.item(0);
				titol = eTitol.getTextContent();

				NodeList nAny = ePelicula.getElementsByTagName("any");
				Element eAny = (Element)nAny.item(0);
				any = eAny.getTextContent();

				NodeList nDirector = ePelicula.getElementsByTagName("director");
				Element eDirector = (Element)nDirector.item(0);
				director = eDirector.getTextContent();

				NodeList nArgument = ePelicula.getElementsByTagName("argument");
				Element eArgument = (Element)nArgument.item(0);
				argument = eArgument.getTextContent();

				NodeList nImatge = ePelicula.getElementsByTagName("imatge");
				Element eImatge = (Element)nImatge.item(0);
				imatge = eImatge.getTextContent();
				
				// Creem una nova pelicula amb la informacio obtinguda
                                this.m_multiCine.getCartellera().addPelicula(this.m_dataManager.crearPelicula(id, titol, any, director, argument, imatge));
                        }
		}
	}

	/**
	 * Obte els cinemes de la cadena Multicine
	 * 
	 * @param doc document XML del que obtenir les dades
	 */
	private void obtenirCinemes(Document doc) {
		NodeList cinemes = doc.getElementsByTagName("cinema");
		String id, nom, direccio;
		int numCinemes = cinemes.getLength();

		// Parsejo tots els elements cinema
		for(int i=0; i<numCinemes; i++) {
			Node cinema = cinemes.item(i);

			if(cinema.getNodeType() == Node.ELEMENT_NODE){
				id = cinema.getAttributes().getNamedItem("id").getTextContent();
				Element eCinema = (Element)cinema;

				NodeList nNom = eCinema.getElementsByTagName("nom");
				Element eNom = (Element)nNom.item(0);
				nom = eNom.getTextContent();

				NodeList nDir = eCinema.getElementsByTagName("direccio");
				Element eDir = (Element)nDir.item(0);
				direccio = eDir.getTextContent();

				// Creem el cinema
				this.m_dataManager.crearCinema(eCinema, id, nom, direccio);

				// Obtenim informacio sobre les sales del cinema
				this.obtenirSalesDeCinema(eCinema);
				this.obtenirOfertesDeCinema(eCinema);
			}
		}
	}

	/**
	 * Obte informacio sobre les sales d'un cinema
	 * 
	 * @param eCinema cinema del que buscar les sales
	 */
	private void obtenirSalesDeCinema(Element eCinema) {
		NodeList sales = eCinema.getElementsByTagName("sala");
		String numSala, capacitat;
		int numSales = sales.getLength();

		// Parsejo tots els elements sala
		for(int i=0; i<numSales; i++) {
			Node sala = sales.item(i);

			if(sala.getNodeType() == Node.ELEMENT_NODE){
				numSala = sala.getAttributes().getNamedItem("numero").getTextContent();
				capacitat = sala.getAttributes().getNamedItem("capacitat").getTextContent();
				Element eSala = (Element)sala;

				// Creem una nova sala
				this.m_dataManager.crearSala(eSala, numSala, capacitat);

				// Obtenim informacio sobre les sessions de la sala
				this.obtenirSessionsDeSala(eSala);
			}			
		}
	}

	/**
	 * Obte informacio sobre les ofertes d'un cinema
	 * 
	 * @param eCinema cinema del que buscar les sales
	 */
	private void obtenirOfertesDeCinema(Element eCinema) {
		NodeList ofertes = eCinema.getElementsByTagName("oferta");
		String id, pelicula, dataInici, dataFi, descompte;
		int numOfertes = ofertes.getLength();

		// Parsejem tots els elements sala
		for(int i=0; i<numOfertes; i++) {
			Node oferta = ofertes.item(i);

			if(oferta.getNodeType() == Node.ELEMENT_NODE){
				id = oferta.getAttributes().getNamedItem("id").getTextContent();
				pelicula = oferta.getAttributes().getNamedItem("pelicula").getTextContent();
				Element eOferta = (Element)oferta;

				NodeList nDataInici = eOferta.getElementsByTagName("dataInici");
				Element eDataInici = (Element)nDataInici.item(0);
				dataInici = eDataInici.getTextContent();

				NodeList nDataFi = eOferta.getElementsByTagName("dataFi");
				Element eDataFi = (Element)nDataFi.item(0);
				dataFi = eDataFi.getTextContent();

				NodeList nDescompte = eOferta.getElementsByTagName("descompte");
				Element eDescompte = (Element)nDescompte.item(0);
				descompte = eDescompte.getTextContent();

				// Creem la oferta
				this.m_dataManager.crearOferta(id, pelicula, dataInici, dataFi, descompte);
			}			
		}
	}

	/**
	 * Obte informacio sobre les sessions d'una sala
	 * 
	 * @param eSala sala de la que obtenir les sessions
	 */
	private void obtenirSessionsDeSala(Element eSala) {
		NodeList sessions = eSala.getElementsByTagName("sessio");
		String pelicula, numSessio, hora, duracio;
		int numSessions = sessions.getLength();

		// Parsejo tots els elements sala
		for(int i=0; i<numSessions; i++) {
			Node sessio = sessions.item(i);

			if(sessio.getNodeType() == Node.ELEMENT_NODE){
				pelicula = sessio.getAttributes().getNamedItem("pelicula").getTextContent();
				numSessio = sessio.getAttributes().getNamedItem("sessioSala").getTextContent();
				Element eSessio = (Element)sessio;

				NodeList nHora = eSessio.getElementsByTagName("hora");
				Element eHora = (Element)nHora.item(0);
				hora = eHora.getTextContent();

				NodeList nDuracio = eSessio.getElementsByTagName("duracio");
				Element eDuracio = (Element)nDuracio.item(0);
				duracio = eDuracio.getTextContent();

				// Creem la sessio
				this.m_dataManager.crearSessio(pelicula, numSessio, hora, duracio);
			}			
		}
	}

	/**
	 * Obte informacio sobre els administradors 
	 * 
	 * @param doc fitxer XML del que obtenir les dades
	 */
	private void obtenirAdministradors(Document doc) {
		NodeList admins = doc.getElementsByTagName("admin");
		String id, nom, usuari, password;
		int numAdmins = admins.getLength();

		// Parsejo tots els elements admin
		for(int i=0; i<numAdmins; i++) {
			Node admin = admins.item(i);

			if(admin.getNodeType() == Node.ELEMENT_NODE){
				id = admin.getAttributes().getNamedItem("id").getTextContent();
				Element eAdmin = (Element)admin;

				NodeList nNom = eAdmin.getElementsByTagName("nom");
				Element eNom = (Element)nNom.item(0);
				nom = eNom.getTextContent();

				NodeList nUsuari = eAdmin.getElementsByTagName("usuari");
				Element eUsuari = (Element)nUsuari.item(0);
				usuari = eUsuari.getTextContent();

				NodeList nPassword = eAdmin.getElementsByTagName("password");
				Element ePassword = (Element)nPassword.item(0);
				password = ePassword.getTextContent();
                                

				this.m_dataManager.crearAdmin(id, nom, usuari, password);
			}
		}
	}

	/**
	 * Obte informacio sobre els clients
	 * 
	 * @param doc fitxer XML del que obtenir les dades
	 */
	private void obtenirClients(Document doc) {
		NodeList clients = doc.getElementsByTagName("client");
		String id, nom, usuari, password, vip;
		int numAdmins = clients.getLength();

		// Parsejo tots els elements client
		for(int i=0; i<numAdmins; i++) {
			Node client = clients.item(i);

			if(client.getNodeType() == Node.ELEMENT_NODE){
				id = client.getAttributes().getNamedItem("id").getTextContent();
				vip = client.getAttributes().getNamedItem("vip").getTextContent();
				Element eClient = (Element)client;

				NodeList nNom = eClient.getElementsByTagName("nom");
				Element eNom = (Element)nNom.item(0);
				nom = eNom.getTextContent();

				NodeList nUsuari = eClient.getElementsByTagName("usuari");
				Element eUsuari = (Element)nUsuari.item(0);
				usuari = eUsuari.getTextContent();

				NodeList nPassword = eClient.getElementsByTagName("password");
				Element ePassword = (Element)nPassword.item(0);
				password = ePassword.getTextContent();

				// Creem el cinema
				this.m_dataManager.crearClient(id, nom, usuari, password, vip);
			}
		}
	}
}

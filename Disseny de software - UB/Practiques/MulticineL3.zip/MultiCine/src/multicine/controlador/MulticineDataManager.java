package multicine.controlador;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import multicine.model.Administrador;
import multicine.model.Cinema;
import multicine.model.Client;
import multicine.model.ClientVip;
import multicine.model.MultiCine;
import multicine.model.Oferta;
import multicine.model.Pelicula;
import multicine.model.Sala;
import multicine.model.Sessio;
import org.w3c.dom.Element;

/**
 * Data manager per Multicine. Crea les estructures de dades necessàries 
 * per a manegar l'aplicació de gestió d'Multicine.
 * 
 * @author Professors disseny
 *
 */
public class MulticineDataManager {

	/* -------------------------------------------------------------------
	 * Metodes a implementar per vosaltres. En aquests metodes creareu els
	 * vostres objectes a partir de la informacio obtinguda del fitxer XML
	 * 
	 * Podeu esborrar els prints si voleu. Tambe podeu canviar el tipus de
	 * dades que retorna el metode, es a dir que sou lliures de
	 * modificar-ho al gust, excepte les crides inicials que es fan.
	 * -------------------------------------------------------------------
	 */
        
	/**
	 * Obté les dades del fitxer XML passat per paràmetre
	 * 
	 * @param nomFitxer ruta del fitxer XML del que obtenir les dades
	 */
	public void obtenirDades(String nomFitxer) {
            MulticineXMLParser parser = new MulticineXMLParser(this);
            parser.parse(nomFitxer);
	}

	/**
	 * Crea una nova pelicula a partir de la informacio obtinguda del fitxer XML
	 * 
	 * @param id id de la pelicula. El podeu utilitzar o no
	 * @param titol titol de la pelicula
	 * @param any and de la pelicula
	 * @param director director de la pelicula
	 * @param argument argument de la pelicula
	 * @param imatge ruta de la imatge de la caratula
	 */
	public Pelicula crearPelicula(String id, String titol, String any, String director, String argument, String imatge) {		
            return new Pelicula(id, titol, director, argument, imatge, Integer.parseInt(any));
	}

	/**
	 * Crea un nou cinema a partir de la informacio obtinguda del fitxer XML
	 * 
	 * @param id id del cinema. El podeu utilitzar o no
	 * @param nom nom del cinema
	 * @param direccio direccio del cinema
	 */
	public Cinema crearCinema(Element eCinema, String id, String nom, String direccio) {
            return  new Cinema(id, nom, direccio);
	}

	/**
	 * Crea una nova sala a partir de la informacio obtinguda del fitxer XML
	 * 
	 * @param numero numero de sala
	 * @param capacitat numero de butaques de la sala
	 */
	public Sala crearSala(Element eSala, String numero, String capacitat) {
            return new Sala(Integer.parseInt(numero),Integer.parseInt(capacitat));
	}

	/**
	 * Crea una nova oferta a partir de la informacio obtinguda del fitxer XML
	 * 
	 * @param id id de la oferta
	 * @param pelicula pelicula ofertada
	 * @param dataInici data d'inici de la oferta
	 * @param dataFi data final de la oferta
	 * @param descompte descompte aplicable 
	 */
	public Oferta crearOferta(String id, String pelicula, String dataInici, String dataFi, String descompte) {
            /*TODO : dataInici -> date , dataFi -> date
            */
            Date dataInic;
            Date dataFinal;
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            try{
                dataInic = df.parse(dataInici);
                dataFinal = df.parse(dataFi);
                return new Oferta(Integer.parseInt(id), Integer.parseInt(descompte), dataInic, dataFinal );
            }catch(ParseException e){
                e.printStackTrace();
            }
            return null;
        }

	/**
	 * Crea una nova sessio a partir de la informacio obtinguda del fitxer XML
	 * 
	 * @param pelicula pelicula visionada a la sessio
	 * @param numero numero de sessio
	 * @param hora hora de la sessio
	 * @param duracio duracio de la sessio
	 */
	public Sessio crearSessio(String pelicula, String numero, String hora, String duracio) {
            Date horaSessio;
            Date duracioSessio;
            DateFormat df = new SimpleDateFormat("HH:mm");
            try{
                horaSessio = df.parse(hora);
                duracioSessio = df.parse(duracio);
                return new Sessio(Integer.parseInt(numero), horaSessio, duracioSessio);
            }catch(ParseException e){
                e.printStackTrace();
            }
            return null;
            
            
            
	}

	/**
	 * Crea un nou admin a partir de la informacio obtinguda del fitxer XML
	 * 
	 * @param id id del administrador
	 * @param nom nom del administrador
	 * @param usuari usuari del administrador
	 * @param password password del administrador
	 */
	public Administrador crearAdmin(String id, String nom, String usuari, String password) {

            return new Administrador(usuari, password,nom,id);
	}

	/**
	 * Crea un nou client a partir de la informacio obtinguda del fitxer XML
	 * 
	 * @param id id del client
	 * @param nom nom del client
	 * @param usuari usuari al sistema del client
	 * @param password password del client
	 * @param vip true si el client es vip. false si no
	 */
	public Client crearClient(String id, String nom, String usuari, String password, String vip) {
            if(vip.equals("true")){
                return new ClientVip(usuari, password, nom, id, 0);
            }else{
                return new Client(usuari, password, nom, id);
            }
	}
}

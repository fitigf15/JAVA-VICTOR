/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

/**
 *
 * @author Victor
 */
public class Usuari {
    private String m_nom;
    private String m_username;
    private String m_password;
    private String m_id;
    public Usuari(String username, String password, String nom, String id){
        this.m_username=username;
        this.m_password=password;
        this.m_nom=nom;
        this.m_id=id;
    }
    
}

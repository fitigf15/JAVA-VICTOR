/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;
/**
 *
 * @author Victor
 */
import java.util.Date;
public class Oferta {
    private int m_tipusDescompte;
    private int m_id;
    private Date m_dataInici;
    private Date m_dataFinal;
    public Oferta(int id,int tipusDescompte, Date dataInici, Date dataFinal){
        this.m_tipusDescompte=tipusDescompte;
        this.m_dataInici=dataInici;
        this.m_dataFinal=dataFinal;
        this.m_id = id;
    }
    
}

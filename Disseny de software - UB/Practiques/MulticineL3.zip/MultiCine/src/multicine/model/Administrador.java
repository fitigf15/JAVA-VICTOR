/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

import java.util.Date;

/**
 *
 * @author Victor
 */
public class Administrador extends Usuari {

    public Administrador(String username, String password,String nom, String id) {
        super(username, password, nom, id);
    }
    public ClientVip crearClientVip(Client c, int tipusDescompte){
        ClientVip cv = (ClientVip) c;
        cv.setTipusDescompte(tipusDescompte);
        return cv;
    }
    
}

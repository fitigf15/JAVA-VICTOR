/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

import java.util.Date;

/**
 *
 * @author Victor
 */
public class Sessio {
    /*
    sessio pelicula="regresoAlFuturo" sessioSala="1">
            <hora>11:00</hora>
            <duracio>1:45</duracio>
    </sessio>
    */
    private Date m_hora;
    private Date m_duracio;
    private int m_id;
    
    
    public Sessio(int id, Date hora, Date duracio){
        this.m_id= id;
        this.m_hora = hora;
        this.m_duracio = duracio;
    }
    
}

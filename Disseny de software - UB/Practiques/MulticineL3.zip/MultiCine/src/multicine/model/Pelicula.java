/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

/**
 *
 * @author Victor
 */
public class Pelicula {
    /**
     * En aquesta classe .......
     */
    private String m_id;
    private String m_titol;
    private String m_argument;
    private String m_imatge;
    private String m_director;
    private int m_anyCreacio;
    private Oferta m_Oferta;
    
    
    public Pelicula(String id,String titol, String director,String argument,String imatge,int anyCreacio){
        this.m_id = id;
        this.m_titol=titol;
        this.m_argument=argument;
        this.m_imatge=imatge;
        this.m_anyCreacio=anyCreacio;
        this.m_director=director;
        this.m_Oferta = null;
    }
    
    public String getId(){
        return this.m_id;
    }
    /**
     * En retorna el titol
     * @return titol
     */
    public String getTitol(){
        return this.m_titol;
    }
    public String getArgument(){
        return this.m_argument;
    }
    public String getImatge(){
        return this.m_imatge;
    }
    public int getAnyCreacio(){
        return this.m_anyCreacio;
    }
    public String getDirector(){
        return this.m_director;
    }
    public void setTitol(String titol){
        this.m_titol=titol;
    }
    public void setArgument(String argument){
        this.m_argument=argument;
    }
    public void setImatge(String imatge){
        this.m_imatge=imatge;
    }
    public void setAnyCreacio(int anyCreacio){
        this.m_anyCreacio=anyCreacio;
    }
    public void setDirector(String director){
        this.m_director=director;
    }
    
    public void setOferta(Oferta oferta){
        this.m_Oferta = oferta;
    }
    public Oferta getOferta(){
        return this.m_Oferta;
    }
    
}

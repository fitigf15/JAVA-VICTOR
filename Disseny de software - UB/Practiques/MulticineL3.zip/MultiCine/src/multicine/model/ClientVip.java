/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

import java.util.Date;

/**
 *
 * @author Victor
 */
public class ClientVip extends Client{
    private int m_tipusDescompte;
    public ClientVip(String username, String password, String nom,String id, int tipusDescompte) {
        super(username, password, nom, id);
        this.m_tipusDescompte=tipusDescompte;
    }
    public void setTipusDescompte(int tipusDescompte){
        this.m_tipusDescompte=tipusDescompte;
    }
    
}

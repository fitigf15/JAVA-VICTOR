/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Victor
 */
public class MultiCine {
    private ArrayList<Usuari> m_usuaris;
    private ArrayList<Compra> m_compres;
    private ArrayList<Cinema> m_cinemes;
    private Cartellera m_cartellera;
    
     public Cartellera getCartellera(){
        return this.m_cartellera;
    }
    //METODES USUARI
    public boolean addUsuari(Usuari usuari){
        return this.m_usuaris.add(usuari);
    }
   
    public boolean addCompra(Compra c){
        return this.m_compres.add(c);
    }
    
    public boolean addCinema(Cinema c){
        return this.m_cinemes.add(c);
    }
    
    /**
     * Ens retorna un string amb tota la informació bàsica de cada pel·lícula
     * @return informacio_cartellera     
    */
    public String veure_cartellera(){
        return "";
    }
    public String mostrar_peliucula(int id){
        return "";
    }
    public String informe_pelicules(){
        return "";
    }
    public String informe_compra_clients(){
        return "";
    }
    public boolean inicar_sessio(String usuari, String contrassenya){
        return false;
    }
    
    public boolean comprar_entrada(){
        return false;
    }
    public boolean solicitar_alta(){
        return false;
    }

    public void addOferta(Oferta o) {
        
    }

    public void addSessio(Sessio s) {
    }

    public void addPelicula(Pelicula p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void addSala(Sala s) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
            
    
    
    
    
}

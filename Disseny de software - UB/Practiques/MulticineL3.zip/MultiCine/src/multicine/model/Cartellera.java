/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 *
 * @author Victor
 */
public class Cartellera{
    private ArrayList<Pelicula> m_pelicules;
    
    public boolean addPelicula(Pelicula pelicula){
        return this.m_pelicules.add(pelicula);
    }
    
    public Pelicula getPelicula(String id){
        for(Pelicula p:this.m_pelicules){
            if(p.getId().equals(id)){
                return p;
            }
        }
        return null;
        
    }
    
    
}

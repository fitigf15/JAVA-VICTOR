/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicine.model;

/**
 *
 * @author Victor
 */
public class Butaca {
    private int m_fila;
    private int m_columna;
    private boolean m_isLliure;
    
    public Butaca(int fila,int columna,boolean isLliure){
        this.m_fila=fila;
        this.m_columna=columna;
        this.m_isLliure=isLliure;
    }
    public void setIsLliure(boolean isLliure){
        this.m_isLliure=isLliure;
    }
    public int getFila(){
        return m_fila;
    }
    public int getColumna(){
        return m_columna;
    }
    public boolean getIsLliure(){
        return m_isLliure;
    }
}
